# Introduction

This package provides common code functionality to edit 2D polygonal shapes and B-splines in custom ``EditorWindow`` and ``SceneView``. 

The package is currently for internal use only, and not meant for public use at this time.
