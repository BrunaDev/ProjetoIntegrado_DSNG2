2D Common

# Introduction

This package contains shared code used by various 2D packages such as Sprite Shape and 2D Animation.

The package is currently for internal use only, and not meant for public use at this time.
