using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent (typeof(Rigidbody2D))]
public class arrow : MonoBehaviour
{
    [SerializeField]
    private float velocidade;

    [SerializeField]
    private GameObject explosao;

    private Vector2 direcao;
    private float tempo = 0.08f;

    private Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        rb.velocity = direcao * velocidade;
    }

    public void Inicializar(Vector2 _direcao){
        direcao = _direcao;
    }

    void OnBecameInvisible() 
    {
        Destroy(gameObject);//destroi a flecha quando ela sai da tela
    }

    void OnTriggerEnter2D(Collider2D outro) 
    {
        if(outro.gameObject.tag == "Inimigo")    
        {//destroi a flecha quando um inimigo é atingido
            explosao.SetActive(true);
            
            StartCoroutine("Destruir"); //chama o método destruir
        }
    }

    IEnumerator Destruir()//esse método permite que a flecha execute a explosão antes de sumir, em outras palavras, dá um delay na destruição da flecha para executar a animação 
    {
        yield return new WaitForSeconds(tempo);
        Destroy(gameObject);
    }
}
