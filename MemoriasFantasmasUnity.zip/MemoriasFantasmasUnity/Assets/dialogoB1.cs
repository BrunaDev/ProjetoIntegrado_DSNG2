using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dialogoB1 : MonoBehaviour
{
    public GameObject image;
    public bool trigger;
    void Start()
    {
        
    }

   
    void Update()
    {
      if (Input.GetKeyDown(KeyCode.E) && trigger == true)
        {
            if (image.activeInHierarchy)
            {
                image.SetActive(false);
            }
            else
            {
                image.SetActive(true);
            }

        } 
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            trigger = true;
            Debug.Log("colidiu");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            trigger = false;
            image.SetActive(false);
            Debug.Log("colidiu");

        }
    }
}
