using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMoviment : MonoBehaviour
{
    Animator anim;
    public float Run;
    public float Idle;
    

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

// Update is called once per frame
    void Update()
    {
        Move();
    }

    private void Move()
    {
        Vector3 movement = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0f);
        transform.position += movement * Idle * Time.deltaTime;

        //Andar para a direita
        if(Input.GetAxis("Horizontal") > 0f){
            anim.SetBool("idle_right", true);
            transform.eulerAngles = new Vector3(0f,0f,0f);
            if(Input.GetKeyDown(KeyCode.Space) == true){
                anim.SetBool("run_right", true);
                Idle += Run;
               
            }
            if(Input.GetKeyUp(KeyCode.Space) == true){
                anim.SetBool("run_right", false);
                Idle = 2;
               
            }
        }

        //Ir para a esquerda
        if(Input.GetAxis("Horizontal") < 0f){
            anim.SetBool("idle_left", true);
            transform.eulerAngles = new Vector3(0f,180f,0f); //espelha o sprite fazendo o personagem virar para a esquerda
            if(Input.GetKeyDown(KeyCode.Space) == true){//se space for pressionado, chama a animaçao de correr
                anim.SetBool("run_left", true);
                Idle += Run;
                transform.eulerAngles = new Vector3(0f,180f,0f);
                
            }
            if(Input.GetKeyUp(KeyCode.Space) == true){//se space for soltado, ele retira a animação de correr
                anim.SetBool("run_left", false);
                Idle = 2;
                transform.eulerAngles = new Vector3(0f,180f,0f);
              
            }
        }

        //Ficar parado enquanto vai para esquerda ou direita
        if(Input.GetAxis("Horizontal") == 0f){
            anim.SetBool("idle_right", false);
            anim.SetBool("idle_left", false);
          
            
        }

        //Ir para cima
         if(Input.GetAxis("Vertical") > 0f){
            anim.SetBool("idle_up", true);
            
        }

        //Ir para baixo
         if(Input.GetAxis("Vertical") < 0f){
            anim.SetBool("idle_down", true);
            
        }

        //Ficar parado enquanto vai para cima ou baixo
        if(Input.GetAxis("Vertical") == 0f){
            anim.SetBool("idle_up", false);
            anim.SetBool("idle_down", false);
           
            
        }

        if(Input.GetKeyDown(KeyCode.LeftAlt)){
            anim.SetBool("attack", true);
        }
    }
}
