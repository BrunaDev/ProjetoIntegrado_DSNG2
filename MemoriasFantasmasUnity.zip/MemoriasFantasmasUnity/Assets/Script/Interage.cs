using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interage : MonoBehaviour
{
    public GameObject CaixadeDialogo;
    public GameObject playerCef;
    public bool trigger;
   
    void Update()
    {
      if (Input.GetKeyDown(KeyCode.C) && trigger == true)
        {
            if (CaixadeDialogo.activeInHierarchy)
            {
                CaixadeDialogo.SetActive(false);
            }
            else
            {
                CaixadeDialogo.SetActive(true);
            }      
        
        } 
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            trigger = true;
            Debug.Log("colisao");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            trigger = false;
            CaixadeDialogo.SetActive(false);
            Debug.Log("colisao");
        
        }
    }
}